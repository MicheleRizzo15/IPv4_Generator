var searchData=
[
  ['formatta_0',['Formatta',['../class_i_pv4__generate_1_1_i_pv4.html#a1d1a221347bc0db3b0d5b2903449d7ba',1,'IPv4_generate.IPv4.Formatta(string intestazione, string dec, string bin)'],['../class_i_pv4__generate_1_1_i_pv4.html#a6130ef5b17418fd1adeb0e1801478d5e',1,'IPv4_generate.IPv4.Formatta(string intestazione, int intero)']]]
];
