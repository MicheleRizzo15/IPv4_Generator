var indexSectionsWithContent =
{
  0: ".abcefgimnpst",
  1: "aip",
  2: "i",
  3: ".aip",
  4: "abcefgimst",
  5: "bcis",
  6: "bcins"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "Namespace",
  3: "File",
  4: "Funzioni",
  5: "Variabili",
  6: "Proprietà"
};

