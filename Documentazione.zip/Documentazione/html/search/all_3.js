var searchData=
[
  ['cidr_0',['cidr',['../class_i_pv4__generate_1_1_address_generator.html#a083f49ff100d08fb10a4ed049d9a22c2',1,'IPv4_generate::AddressGenerator']]],
  ['cidr_1',['Cidr',['../class_i_pv4__generate_1_1_i_pv4.html#ab32dc83e105b1cc04a6a02fa6b753dae',1,'IPv4_generate::IPv4']]],
  ['controllosubnet_2',['ControlloSubnet',['../class_i_pv4__generate_1_1_i_pv4.html#a687e799be3575569b1811f0e6ce35394',1,'IPv4_generate.IPv4.ControlloSubnet(bool[] sb, out int err)'],['../class_i_pv4__generate_1_1_i_pv4.html#a07ee9de1071b36d643c5a5a885830dcd',1,'IPv4_generate.IPv4.ControlloSubnet(bool[] sb)']]]
];
