var searchData=
[
  ['netid_0',['NetId',['../class_i_pv4__generate_1_1_i_pv4.html#af631f94f77f95ad36351e52e8308403d',1,'IPv4_generate::IPv4']]],
  ['netidip_1',['NetIdIp',['../class_i_pv4__generate_1_1_i_pv4.html#a6b53c234c0888c6d650dbeeab5d616e3',1,'IPv4_generate::IPv4']]]
];
