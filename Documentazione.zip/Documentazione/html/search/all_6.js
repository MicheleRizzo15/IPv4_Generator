var searchData=
[
  ['generateipv4_0',['generateIPv4',['../class_i_pv4__generate_1_1_address_generator.html#a7ccc4391e9f38c3e8c3a8e6d56c6de6e',1,'IPv4_generate.AddressGenerator.generateIPv4()'],['../interface_i_pv4__generate_1_1_i_address.html#abcd8fb76e437e87e80b4855bd4d81e12',1,'IPv4_generate.IAddress.generateIPv4()']]],
  ['generatesubnet_1',['generateSubnet',['../class_i_pv4__generate_1_1_address_generator.html#acac137293d86e3c7e45fb9cbe63388f1',1,'IPv4_generate.AddressGenerator.generateSubnet()'],['../interface_i_pv4__generate_1_1_i_address.html#a8b0c96f95eb01317dc2737216ff0e897',1,'IPv4_generate.IAddress.generateSubnet()']]],
  ['getbroadcast_2',['GetBroadcast',['../class_i_pv4__generate_1_1_i_pv4.html#ae76b55c33d7f9a90ff6ff07f89f588c4',1,'IPv4_generate::IPv4']]],
  ['getcidrfromsubnet_3',['GetCidrFromSubnet',['../class_i_pv4__generate_1_1_i_pv4.html#aabf7a6e8e210bab977326fef098cfff8',1,'IPv4_generate.IPv4.GetCidrFromSubnet(bool[] sbTmp)'],['../class_i_pv4__generate_1_1_i_pv4.html#a2d2dc9b20a802b9041d5716c12180c68',1,'IPv4_generate.IPv4.GetCidrFromSubnet(byte[] sbTmp)']]],
  ['getnetid_4',['GetNetId',['../class_i_pv4__generate_1_1_i_pv4.html#a533e9bed45468c99cf18a388678f8e74',1,'IPv4_generate::IPv4']]],
  ['getsubnetfromcidrbool_5',['GetSubnetFromCidrBool',['../class_i_pv4__generate_1_1_i_pv4.html#ac439263456be2b879232a1776572c851',1,'IPv4_generate::IPv4']]],
  ['getsubnetfromcidrbyte_6',['GetSubnetFromCidrByte',['../class_i_pv4__generate_1_1_i_pv4.html#aad4d5b48f1755e9f8228ef656b48c5bc',1,'IPv4_generate::IPv4']]]
];
