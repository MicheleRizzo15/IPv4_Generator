var searchData=
[
  ['controllosubnet_0',['ControlloSubnet',['../class_i_pv4__generate_1_1_i_pv4.html#a687e799be3575569b1811f0e6ce35394',1,'IPv4_generate.IPv4.ControlloSubnet(bool[] sb, out int err)'],['../class_i_pv4__generate_1_1_i_pv4.html#a07ee9de1071b36d643c5a5a885830dcd',1,'IPv4_generate.IPv4.ControlloSubnet(bool[] sb)']]]
];
