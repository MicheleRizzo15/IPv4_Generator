var searchData=
[
  ['ipv4_0',['IPv4',['../class_i_pv4__generate_1_1_i_pv4.html#a7403deb296a9e40ed99822aeab604840',1,'IPv4_generate.IPv4.IPv4()'],['../class_i_pv4__generate_1_1_i_pv4.html#aa663931e54d5b0a1868df93a59231df3',1,'IPv4_generate.IPv4.IPv4(bool[] ip, bool[] sb, bool isHost=false)'],['../class_i_pv4__generate_1_1_i_pv4.html#ad338716ef2aca8f415c39121bfd27d34',1,'IPv4_generate.IPv4.IPv4(byte[] ip, byte[] sb, bool isHost=false)'],['../class_i_pv4__generate_1_1_i_pv4.html#a28af59eebd9f46d294765ef9ead24de5',1,'IPv4_generate.IPv4.IPv4(byte[] ip, int cidr, bool isHost=false)'],['../class_i_pv4__generate_1_1_i_pv4.html#ad1472d6d85969f63dea0c60bfdb4e62c',1,'IPv4_generate.IPv4.IPv4(bool[] ip, int cidr, bool isHost=false)']]]
];
